# Diablo Survivors

Windows playable source package. Python 3.12 or newer (64-bit) must be installed and available as `python`.

Notice: No existing saves, cached assets, game archives or original Diablo images/audio are included in this project.

1. Run **Setup.bat** once. Internet access is required to install the Python dependencies, Godot 4.6.2, and StormLib 9.40. Godot and StormLib downloads are checksum verified.
2. Run **Run_Diablo_Survivors.bat**.
3. Choose Diablo I or classic Diablo II and select your own installed game folder. Original graphics/audio are imported locally; the first import takes longer than subsequent launches.

Diablo II with or without Lord of Destruction is supported; Resurrected / Infernal Edition is unsupported. 
LoD enables seven class unlocks instead of five. 
Diablo I has three class unlocks.

Select a character, area and difficulty, then Play. 
Easy lasts 8 minutes, Hard 12, and Legendary 16. 

Earn gold through challenges and buy permanent upgrades. 

Movement: WASD/arrows; T to turn Auto-Attack on or off; pause: Space/Esc; upgrades: 1–3; character sheet: C; mute: M.

Caches, game-selection settings and progress are created in `.local` beside this package. 
Keep that folder to retain progress. 

Tested source versions: 
Diablo I GOG English executable product version 1.0.9.2; 
classic Diablo II base 1.0.0.1 inspected/representative assets decoded; 
Diablo II LoD English 1.0.7.0 imported and played with all seven classes. 
Base-only mode was also tested with expansion archives excluded from the current installation.

The Python files are required for game selection and asset import. 
This is not a standalone EXE distribution. 

See LICENSE and THIRD_PARTY_NOTICES.md for licensing. 
Dependencies are installed by Setup rather than bundled here.

Settings are available from the main menu and pause menu: music on/off, music and SFX volume, and damage screen shake on/off. 
Preferences persist between launches. 
Each map loops its original regional soundtrack; maps in the same region share a track. 
D2 music needs d2music.mpq in the selected installation.

## Features

- Choose Diablo I or classic Diablo II graphics and audio from your own installation; switch games from the main menu.
- Automatic installation identification, asset indexing, and local caching for faster repeat launches.
- Three unlockable Diablo I classes; five Diablo II classes, or seven with Lord of Destruction.
- D1 has 22 survival areas. D2 has its own 101 combat areas across Acts I–IV, or 124 across Acts I–V with LoD. Easy lasts 8 minutes, Hard 12, and Legendary 16; beating Legendary unlocks the next area.
- Automatic attacks while moving, varied damage, critical hits, floating damage numbers, and distinct class attacks.
- 29 run upgrades with tiers and maximum ranks, including weapon damage, piercing projectiles, multi-shot up to five projectiles, larger attack areas, additional targets, and independent minions.
- Increasing level-up costs: each next level requires 1.75 times the previous XP requirement, rounded up.
- Sequential enemy challenges with first-time gold rewards, achievements, and repeat-completion records.
- Permanent upgrades with increasing prices, purchased using saved gold.
- Timed collectible boosts lasting at least 35 seconds, duration upgrades, and respawns spaced at least one screen apart.
- Neon square pickup borders, rising magical motes, boost-colored foot mist, and a nearby-collectibles minimap.
- Maps wrap at opposite edges; enemies, attacks, and loot remain nearby across boundaries.
- Original attack, hit, death, pickup, and regional music audio from the selected game.
- Settings for music on/off, music volume, SFX volume, and damage screen shake; preferences are saved.
- Health-dependent HP colors, a light-blue XP bar, red damage screen flashes, and optional subtle hit shake.
- Rare treasure goblins and a special timed cow-hunt portal event.
- Saved progress, last-played character/area/difficulty, rewards screens, and Reset Progress with confirmation.
- Final victory message after completing the campaign's final area on Legendary and all its challenges across the three difficulties: Hell Floor 16 for D1, Chaos Sanctuary for base D2, or Worldstone Chamber for LoD.

- Rare Orb Harvest pickups draw all existing XP orbs visibly toward the player, with moving orb trails.
- A hard limit of 300 active enemies across the map, with new spawns allowed when slots become free.
- The main menu plays the selected game's intro/menu theme; regional soundtracks begin when a run starts.

## Diablo I vs Diablo II

Your selected game supplies the graphics, animations, sound effects, and music. Both choices use the same Diablo Survivors progression, difficulty modes, challenges, permanent shop, and survival rules.

| Feature | Diablo I | Classic Diablo II | Diablo II with Lord of Destruction |
| --- | --- | --- | --- |
| Playable classes | 3 | 5 | 7 |
| Classes | Warrior, Rogue, Sorcerer | Barbarian, Amazon, Paladin, Necromancer, Sorceress | All five base classes, plus Assassin and Druid |
| Starting class | Warrior | Barbarian | Barbarian |
| Additional classes | Unlocked through play | Unlocked through play | Unlocked through play; Assassin and Druid require LoD |
| Visuals and audio | Original D1 sprites, scenery, and sounds | Original D2 layered character sprites, floor tiles, and sounds | D2 assets plus expansion character sprites and sounds |

D2 provides more character choices: melee fighters, bow attacks, spells, and the Necromancer's skeletal minions. These are survival-game adaptations of the original classes, rather than their complete original skill trees.

D1 retains its original floor/quest enemy rosters, scenery, collision maps, and impact effects. D2 now has its own Acts and combat areas, with 236 enemy profiles in base-only mode or 309 with LoD, including variants, bosses and mapped named uniques. Areas use original regional floor art in survival layouts; original D2 map geometry and full original monster skill sets are not reproduced.

You only need the game you choose installed. LoD is detected automatically in the selected classic D2 folder. Diablo II: Resurrected / Infernal Edition is not supported. Changing the source game keeps separate D1 and D2 progress; classic D2 and D2 with LoD share the D2 progress profile.

- Timer expiry plays a completion chime and immediately shows the rewards panel. Reward saving runs in the background with a visible saving status.

- Timed enemy surges start with basic melee, gradually introduce ranged variants and elites, and include recovery breaks. Easy targets rise from about 40 to 130 active enemies; Hard and Legendary apply higher pressure while preserving the absolute 300-enemy ceiling. The cow challenge retains continuous spawning.
- Treasure goblins have golden foot particles and a yellow minimap star, including an edge marker when they are outside the nearby-map range.

- Three upgrade rerolls per run, expandable to eight through five ranks of Second chances in the permanent shop (150, 300, 450, 600 and 750 gold). Rerolls replace the current choices with different eligible upgrades, exclude maxed upgrades, and preserve the paused upgrade selection. The allowance is shared with cow-portal excursions and resets for a new run.

Permanent shop tabs are: General, Defense, and Class. Fleet feet is in General. New general/defensive upgrades increase XP gain, timed boost duration, critical chance, passive regeneration, and healing per kill. All retain progressively increasing costs and rank caps.

The Class tab is specific to the selected game and installed expansion. D2 has dedicated upgrades for Barbarian cleave targets, Amazon bow damage, Paladin armor, Necromancer minion damage, Sorceress spell splash, Assassin weapon damage, and Druid regeneration. D1 class options are hidden while using D2, and vice versa; Assassin and Druid options require LoD. Longer lists scroll.

Attack controls: press **T** to toggle auto-attack. With auto-attack off, left-click to attack toward the cursor; manual attacks use the same cooldown. Minions remain active. The bottom-center amber bar shows attack readiness. 

## Bestiary and original areas

| Pack | Enemy profiles | Survival areas |
| --- | ---: | ---: |
| Diablo I | 95 | 22 |
| Diablo II | 236 | 101 |
| Diablo II + Lord of Destruction | 309 | 124 |

D1 imports 95 enemy profiles across its 22 survival areas. D2 imports 236 profiles across 101 combat areas (Acts I–IV), including 31 named uniques; LoD imports 309 profiles across 124 combat areas (Acts I–V), including 46 named uniques. Profile counts include variants and bosses; they are not counts of distinct sprite families. Bosses and named uniques spawn in their assigned areas, and named uniques appear only once per run.

Skeleton mage graphics and projectiles distinguish poison, cold, fire and lightning. Melee/ranged profiles, original stationary profiles, family sound effects and challenges are assigned to each area. Completing Legendary unlocks the next source-specific area.

LoD 1.07 Act V uses explicitly authored native-family roster corrections because its shipped level tables contain pre-release placeholders. Original resurrection, spawning offspring, burrowing, teleporting, curses, unique modifiers and complete boss skill sets remain future work. Towns and empty noncombat maps are omitted from progression; the cow map remains a portal event.

Compatibility metadata ships in catalogs/diablo2. Decoded art/audio and bestiary database tables are cached locally. See [the detailed roster and coverage notes](docs/bestiary.md).

Boss-only rooms use timed endurance encounters: the first boss appears after five seconds and returns after a sixty-second recovery following defeat, with one active main boss at a time. Other named uniques appear only once per run. D2 achievements use D2 areas and the classes available in the selected edition.
