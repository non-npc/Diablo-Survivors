# Project status

Updated: 2026-10-12.

## Implemented

- M0 foundation: organized source layout, PyQt6 library/inspection/settings shell, SQLite persistence, adapter interface, six JSON schemas, Git repository and CI configuration.
- Original Godot 4.6.2 movement demo with bounded arena, SVG hero, manifest input, headless smoke and asynchronous first-run resource preparation. Uses the user's existing Godot installation.
- Separate administrator Game Inspector & Profile Studio: archive inventory, classic MPQ header/table browsing, named/unnamed filters, path probes/candidate lists, version/GOG metadata, resource bytes and palette previews.
- Draft edition/profile catalog editor and atomic pair export. Fingerprint-bound block offsets/sizes/flags retained. Drafts remain inspected, not fully verified.
- Real local resource import via StormLib 9.40 with cancellation, staging rollback, provenance/hashes, palette PNGs, WAV header validation, diagnostics and same-selection cache reuse.
- Run files: Run_Manager.bat, Run_Inspector.bat, Run_Demo.bat; shell entry points, dependency setup, platform build scripts, source-only packager and documentation.

## Validation

Windows / Python 3.14.0 / PyQt6 6.10.0 / Godot 4.6.2: 60 pytest checks passed; all schemas/catalogs validated; inspector startup, Godot headless movement smoke and manager-to-runtime launch passed. Clean source ZIP verified: both apps launched without local data/tool caches; private payloads excluded. Inspector visual rendering checked; Windows offscreen fonts explicitly load the installed system font.

Private Diablo validation: eight archive paths inspected, 39 named resources imported locally, zero extraction diagnostics. The main archive's nine catalogued paths are extracted; 2910 total blocks are present. Repeat scan used saved fingerprints; repeat identical import reused the active batch. Actual draft profile/catalog pair exported under ignored .local/inspector/profile-drafts/. Source installation remains unchanged. String/fixed version differences are recorded in diablo1-feasibility.md.

## Remaining gates and limits

- M0 Windows foundation works; Linux/macOS CI is configured but has not run, so the all-platform gate remains unverified. Source package is not a standalone binary installer.
- M1 combat/survival loop, seeded combat tests and ten-minute manual run remain pending.
- M2 full Diablo importer remains pending: CEL/CL2 rendering/animation metadata, terrain/collision assembly, patch precedence, full catalog/mappings and playable campaign. Raw import is not full format support.
- Earlier non-GOG editions, other languages and other games remain unverified. Hellfire is inventoried, not playable/importer-verified.
- Administrator SQLite asset database and JSON indexes are persistent; production per-asset incremental cache, end-user asset/progression database, explicit integrity rehash UI and native parser isolation remain further work.
- Default sandbox process startup fails in this session; authorized read/write/test operations used escalated execution.

## Automatic preparation update

Folder selection now automatically builds a per-installation assets.sqlite3 database, draft profile/catalog and local working imports. Actual Diablo verification: 3967 database records across eight archives, 39 named/imported resources, no import errors. GUI folder-trigger, unnamed indexing, database/import reuse and activation rollback tests passed. Unnamed resources and incomplete sprite decoding remain explicit; ready_for_gameplay is false.

## Smart identification update

All 3967 archive entries are named using verified matches from MPQ browser candidate lists. Metadata-only catalogs ship for the main GOG archive and full inspected installation. Database schema v2 stores type/format/confidence and format properties. Pipeline 0.3.2 validates images/audio, parses sprite groups/RLE and terrain structures, generates cached previews, and reuses existing raw payloads on decoder upgrades. Inspector supports type filtering, image previews, sprite scrubbing/animation and local audio playback.

Actual coverage: 3900 working resources imported; 1485 audio resources, 130 standard images, 1921 sprite previews, 49 palette swatches and 50 terrain previews/ID visualizations. Two sprite-layout diagnostics remain; automatic widths, palette translations, game actor mappings, full terrain assembly and playable campaigns are incomplete. Raw third-party listfiles and all extracted content remain outside distribution.

## Palette, animation and terrain validation update

Preparation 0.4.1 validates the complete cathedral bundle: 1119 primitives, 453 pieces and 206 composed tiles. Representative skeleton idle/walk/attack/hit/death have 448 fully decoded frames in eight directions, rendered with a chosen level palette and white translation. SQLite currently stores 309 animation mapping candidates and 14 representative resource dependencies. Published catalogs retain the measured animation metadata.

Inspector controls now select palette/TRN/direction, preview composed cathedral tiles and launch a generic Godot imported-resource scene. Real normalized resources and original synthetic fixtures passed the headless preview; invalid sprite bounds were rejected. All 60 pytest checks and manager/runtime startup checks passed.

Remaining: full original timing, other actor/arena palette rules, other terrain families, collision/navigation validation, canonical campaign/resource handoff and M1 survival gameplay. The runtime preview is illustrative and uses authored timing; playable Diablo support is still incomplete.

## Direct imported demo

Run `Run_Imported_Demo.bat` to open the latest validated local resources without navigating the inspector. WASD moves the skeleton and automatically switches idle/walk; hold 3 for attack, 4 for hit, 5 for death; Escape exits. The launcher uses a complete flat floor tile and existing cached sheets. It is an asset/movement demo; combat, enemies, XP and upgrades are the next gameplay milestone. Headless demo and all 60 tests passed.


## Five-minute survival demo

Run `Run_Survival_Demo.bat` after Inspector preparation to play Cathedral Survival using cached local Diablo GOG assets. The Warrior moves with WASD or arrow keys and attacks nearby skeletons automatically. Collect blue XP drops; choose one of three upgrades with 1–3 or click. Space/Escape pauses, R restarts after death or victory. Survive five minutes against increasingly frequent spawns and elite enemies. Six upgrades include damage, attack speed, health, movement, pickup range and up to two allied wisps. Wisps are original geometric effects.

`Run_Synthetic_Survival.bat` runs the same gameplay with original artwork and requires no game installation. Gameplay settings and upgrade definitions live in the survival manifest. Local Diablo manifest: `.local/demo/survival.json`; decoded Warrior sheets: `.local/demo/warrior/`; results: `.local/demo/progress/diablo1.json` (last 50 runs and best scores). Preparation reuses source hashes and cached normalized sheets. Nothing is written to the installed game folder.

This is an authored gameplay prototype with illustrative animation timing, a flat cathedral floor, melee combat and a limited actor set. Full campaign support, terrain collision, additional games, audio integration and final balancing remain future work. Automated checks cover seeded spawning, combat/death/XP, upgrade pause, summons, enemy limits, a five-minute simulation and native scene startup.

Validation result: all 60 Python tests, importer/manager checks, survival rules including full-duration simulation, synthetic scene and local Diablo scene passed on Godot 4.6.2. Gameplay balance and visual feel still need user playtesting.


### Class progression

The survival demo opens on class selection. Warrior is available immediately (100 HP, automatic sword cleave). Rogue unlocks after 500 cumulative kills across completed runs (75 HP, faster movement, automatic arrows). Sorcerer unlocks after a five-minute victory (65 HP, firebolts with splash damage). Locked buttons show their requirements and lifetime progress. Existing saved run history contributes automatically; lifetime totals and unlocks persist beyond the last-50-run history limit. Finished runs record the selected class. Choose class on the results screen; R retries the current class. Abandoned runs do not count.

Diablo class animations are prepared from cached Warrior, Rogue and Sorcerer CL2 files into `.local/demo/classes/` using source-hash cache keys. Projectile graphics are original code-drawn effects; timing and stats are authored for this prototype. Synthetic mode uses the same original avatar for each class while preserving different gameplay.


### Gold and permanent shop

Completed runs award one gold per kill, one per ten seconds survived, plus 50 for victory. The results screen displays earnings; class selection opens the permanent shop. Vitality gives +10 starting HP per rank (50 base price), Power +5% starting damage (75), Haste +3% movement speed (60). Each has ten ranks and its next price equals base price times next rank. Bonuses apply to all classes on the next run; in-run upgrades remain temporary. Gold, purchases, lifetime kills and unlocks share the per-profile progress JSON. Existing retained run history receives gold once during migration; repeat loads do not award it again. Abandoned runs award nothing. Failed save operations keep your gold and do not activate a purchase.


The permanent shop uses Movement, Defense, General and Class tabs. Movement improves run speed; Defense offers maximum HP and contact-damage reduction (minimum one damage per hit); General improves damage and XP collection. Class bonuses add Warrior cleave targets, Rogue bow damage, or Sorcerer firebolt splash radius. Locked classes cannot buy their bonuses. Bonuses use the same gold/save rules and only affect the next run; shared in-run upgrade choices remain separate.

Class/shop validation: 60 Python tests and Godot rules/scene checks passed, including cumulative unlocks, projectile collisions, history retention, gold migration, purchase/save/reload, rank caps and class-specific effects. Shop layout rendered and visually checked on the GTX 1650.

Player movement and movement-driven facing changes are blocked while the attack animation is active, for every class. Held movement resumes after the attack animation ends; pause and upgrade selection freeze the attack timer.


## Original Tristram survival arena and character sheet

Launch `Run_Tristram_Survival.bat` to reconstruct the original base Diablo town from cached `DIABDAT.MPQ` terrain and four sector DUN files. Sector placement follows the format reference: sector1 (46,46), sector2 (46,0), sector3 (0,46), sector4 (0,0). DUN tile IDs are one-based; TIL piece references are zero-based. The normalized 96×96 map preserves buildings, trees, rocks, paths and river. Town quest/warp-state modifications, NPCs and Hellfire town changes are omitted.

The adapter decodes all 3547 referenced primitives, 1258 MIN pieces and 342 TIL tiles. SOL flags supply movement/missile collision; the largest connected region has 3817 walkable cells. Player movement slides at obstacles, enemies use a shared breadth-first distance field with persistent waypoints, ranged shots stop at solid scenery, and spawn locations use connected walkable cells outside the viewport. Raised scenery sorts with actors so the player can walk behind it. This is a survival adaptation of the static town geometry, not original Diablo gameplay or an exact quest-state reconstruction.

Source-hash caches live under `.local/demo/maps/tristram/` (piece atlas, map.json, town-overview.png). `.local/demo/tristram-survival.json` is the runtime manifest; Tristram shares class/gold/shop progression with the cathedral arena. `Run_Survival_Demo.bat` still launches the cathedral. Original pixels/maps remain local and excluded from source distributions.

Press C during play to view the character sheet and close it again. Original `data/char.cel` (320×352) and `ctrlpan/spelicon.cel` (56-pixel frames) are normalized into `.local/demo/ui/` using the town palette. The character panel is used in the sheet; the spell icon atlas is prepared for later icon mappings. The sheet shows current class, level, XP, health, gold, actual combat/movement values, permanent bonuses and selected run upgrades. Original attributes, mana and resistances that the prototype does not implement are shown as dashes. Gameplay and attack timers pause while the sheet is open. Synthetic mode uses the same data sheet without proprietary artwork.

Format references: https://github.com/diasurgical/devilutionX/blob/master/Source/levels/town.cpp and https://github.com/diasurgical/devilution/blob/master/Source/control.cpp (format research only; no third-party game engine code distributed).

Final map/UI validation: 63 Python tests and all Godot scene/model checks passed. Ten sampled routes through the real town reach the player, the imported town scene passes combat/victory smoke, and the original character sheet was rendered and visually inspected. Tristram was launched interactively; balancing across its streets remains user playtesting.


## Tristram performance caching

Map cache version tristram-2 additionally bakes the static ground into town-floor.png and stores tight nontransparent upper-scenery bounds. The runtime draws the ground as one texture, reuses visible scenery lists until the camera leaves a 128×64 region, sorts scenery only on cache rebuild, and merges actors into the preordered scenery without sorting terrain every frame. Empty upper sprites are skipped; props draw cropped atlas regions. Terrain textures, enemy sheets and class sheets remain resident instead of being decoded per frame. Navigation neighbor lists and projected cell centers are computed once per map. Collision, shared flow routing and depth ordering remain active.

Measured on this Windows machine: 150-enemy headless model tick approximately 4.39 ms before / 3.38 ms after; repeated visible-terrain list work approximately 4.12 ms before / 0.21 ms after. Separate native OpenGL test on GTX 1650 averaged approximately 1.70 ms per uncapped rendered frame and 23 draw calls with 150 enemies; model-tick measurement approximately 3.01 ms. These are short benchmark samples, not worst-case gameplay guarantees. The cached ground uses additional texture memory and is prepared once per source hash. `runtime/tests/town_benchmark.gd` provides an opt-in benchmark; pass the local town survival manifest.


## Treasure goblin and eight-minute cow hunt

An original treasure goblin sprite sheet was created with the built-in image_gen tool and is stored at `runtime/resources/treasure_goblin.png`; its complete generation prompt and 4×4 directional layout are recorded in the adjacent `.provenance.json`. The generated transparent image is used unchanged, with four run frames for south/west/east/north directions. This artwork is original and can ship with the source; locally decoded cow art remains private.

Normal survival runs check for a rare goblin every 30 active seconds with an 8% chance, limited to one active goblin. It has 60 HP, flees at speed 135 with brief rests, causes no contact damage, and escapes after 45 seconds. Killing it drops normal XP plus a treasure pickup containing 30 XP, 15 healing and 25 gold. Collect the treasure to add its gold to the normal end-of-run reward. A 1% roll on goblin death opens a cow portal for 60 active seconds. Approach within 85 pixels and press E to enter. Probabilities are authored configuration values; normal launches retain rarity. Each interactive run uses a fresh seed recorded in its summary; smoke tests retain a deterministic seed.

The portal starts an authored pasture survival arena using the locally cached original `towners/animals/cow.cel` animation and town palette, or an original geometric cow in synthetic mode. The base survival run pauses while the hunt is active. The countdown begins at 08:00 and counts active gameplay time down to zero; pause, upgrades and the character sheet pause it as usual. Cows continue spawning after 500 kills, subject to a 220-live-enemy cap. Reaching 500 does not trigger an early completion message or end the hunt. At timer zero, 500 or more cow kills earns exactly TWO gold coins; 499 or fewer earns zero. Cow kills/time do not produce the ordinary survival gold payout. Early defeat earns no cow challenge reward. The event result is saved once. Return to survival restores the suspended base timer and carries current health, XP and run upgrades; defeat also ends the base run. Cow kills count toward cumulative class progression; only a normal survival victory unlocks Sorcerer.

`Run_Treasure_Event_Demo.bat` is an explicit playtest launch: one visible goblin and a guaranteed portal on its death. `Run_Cow_Level_Demo.bat` opens the eight-minute hunt directly. Normal cathedral/Tristram launch files retain the rare spawn and 1% portal chance. The hunt is our own event, not an original Diablo 1 cow level.

Checks cover goblin fleeing, spawn limits, collected loot, forced portal rolls, portal consumption, suspended base timer, full 480-second simulation, continued spawning after 500, exact success/failure payout, save-once behavior and return to the original run.

Cow-hunt countdown: a large top-right timer shows minutes and seconds. At 01:00 remaining it turns red, gains a dark red outline and gently pulses in size/color. It remains legible and does not flash off. Paused gameplay freezes the countdown; urgency is a visual cue and does not alter rewards or spawn rules.

Rare-event validation completed: all 63 Python tests and Godot checks pass. Native rendering was checked for the original generated goblin, locally imported cows and final-minute red timer. Full 480-second model simulation, delayed 500-kill reward, portal/return flow and exact-once persistence passed; combat balance remains playtesting.


## Current area completion and class selection

All normal survival areas now start at 08:00 (480 active seconds), matching the cow hunt. At zero, gameplay stops and the area rewards screen shows area/class, duration, kills by enemy type, collected XP, XP/healing/treasure pickup counts, healing restored, loot gold, total gold earned and wallet balance. These details are recorded with the completed run. Normal rewards still use kills, survival time, victory bonus and collected loot gold; cow hunts retain exactly two gold for 500+ kills at expiry. Early death also shows the collected results. A portal still suspends the previous area and its remaining time until returning. Existing class unlocks remain valid; new Sorcerer unlock text refers to an eight-minute normal-area victory.

Class selection displays a cached first-frame sprite of each class to the left of its text, including disabled/locked classes. Locally imported Warrior/Rogue/Sorcerer art is used when available; synthetic mode uses original project art.

Area/results update verified: 63 Python tests and all Godot model/scene checks passed, including the eight-minute normal-area simulation, zero-time freeze, loot counters and once-only reward saves. Class portraits and rewards were rendered for visual QA. Gold earned is pinned above the scrollable detailed results. The final-minute red countdown now applies to every area.


## Sequential map challenges

Each area has a configured sequence of enemy-specific kill milestones. Cathedral/synthetic: 100, 250, 400 skeletons; Tristram: 75, 175, 300 skeletons; cow hunt: 100, 250, 750 cows. Only the current challenge appears in a compact gameplay line. Reaching its cumulative area kill target unlocks the next; completed and locked challenges do not form a gameplay list. Each completed milestone awards one additional gold only when the eight-minute area timer expires; early death awards no challenge bonus. Rewards show the full sequence, counts and awarded gold; run history stores these details. Progress resets for each new area/run; suspended portal areas retain their own progress. Cow hunt challenge gold is additional to the existing two-gold 500-kill bonus.

Pursuit correction: nearby enemies approach the player directly when a clearance-checked path is open, rather than continuing toward a previous cell waypoint. Waypoints that lead away along the updated distance field are discarded. Obstacle routing remains active; regression coverage moves the player toward an enemy with a stale waypoint.

Corner/combat correction: movement slides along the isometric wall faces using short collision substeps, instead of only screen X/Y. Enemy routes recenter within their current walkable cell when an off-center waypoint path is obstructed. Melee targeting and every cleave hit now require an unobstructed terrain line; splash damage, allied melee and enemy contact damage also respect solid/missile-blocking scenery. Regression checks cover diagonal sliding, blocked melee and valid adjacent attacks.


## Combat audio associations

The Diablo adapter ships metadata-only sound rules in `adapters/diablo1/audio.py`. Preparation writes `.local/demo/audio/audio-mappings.json` containing event names, internal source paths, local WAV paths, source hashes and association confidence. No extracted audio is distributed. Sword swings use Swing/Swing2, Rogue bow fire BFire, Sorcerer firebolt casting Cast2 (verified Firebolt spell-table assignment). Skeleton SkelAxe sound suffixes a/h/d identify attack/hit/death, with two variants each. Hero pain/death uses the respective Warrior/Rogue/Sorcerer 69/71 files. Cow combat associations reuse town cow calls and are explicitly authored, as are firebolt impact choices. Gold collection and rare portal opening also have effects.

Runtime WAV streams are loaded once and shared in an eight-voice pool; two voices are reserved for player effects. Nearby enemy events use distance falloff, stereo panning, quiet volume and per-key throttling; events beyond 650 pixels are dropped. Variants have subtle pitch variation. Combat audio follows authored runtime strike/damage/death events rather than attempting exact original animation-frame timing. Cow calls are associated with our survival combat, not original cow attack animations. The generated treasure goblin has no invented original-game voice; loot and portal sounds supply feedback. M toggles mute; pause, upgrades and character inspection pause effects. Area transitions/restarts stop old voices. Synthetic mode remains silent unless it is given an original sound bank.

Verification covers stream reuse, bounded crowd voices, player voice reservation, range culling, repeat throttling, mute and installed-game WAV loading. Primary format references are recorded in the local mapping document.

Combat audio validation complete: 18 mapped sound events, no missing source files, all installed WAVs load. Stream caching/voice limits/culling/throttling/mute checks and all 63 Python tests plus Godot checks pass. Original animation timing and subjective audio balance remain playtesting.


## Implemented main menu, area chain and lifetime challenge records

Use `Run_GameShift.bat` to open the main menu. Select a character and an unlocked area, then press Play. The menu includes the permanent shop and Achievements & records (achievement badges plus repeat-completion counts per area/challenge). Cathedral is available initially; clearing Cathedral unlocks Tristram. A completed area remains replayable. Repeated clears increment clear counts but do not skip or unlock later areas. Only the two current normal areas are in this chain; the cow hunt remains a special portal event. Explicit treasure/cow playtest launchers bypass ordinary arena access for testing.

Challenge gold is now awarded only for the first timed completion of each challenge in each area. Claimed milestones are skipped by the active HUD on replay, so the next unfinished milestone becomes available. Counts still track every successful repeat for bragging rights, including the special 500-cow challenge. The 500-cow two-gold reward is also once-only. Normal non-challenge run rewards can still be earned on replays. Save migration retains earlier balances/unlocks and infers already-paid challenges from stored run summaries; completion ledgers and counters persist beyond the 50-run history limit. Completion in one area does not claim a challenge with the same ID in another area. Gold and result details are saved exactly once per finished run.

## Implemented tiered in-run upgrades

The authored catalog is `runtime/resources/upgrades.json`: 26 upgrades, typically five ranks, with Spirit Ally capped at two. It includes extra attacks per cycle, +10% area per tier, extra targets, damage, attack interval, health, movement, pickup/weapon range, armor, regeneration, critical chance/power, knockback, healing on kill, healing-drop chance, XP bonuses, wisps and their damage/speed, Warrior bleeding/retaliation, Rogue poison/projectile speed and Sorcerer burning/splash strength. Prerequisites and class eligibility filter choices; capped upgrades leave the pool. Cards mix owned/new choices when possible, show the next tier, exact before/after values and themed icons from the locally decoded spell-icon atlas. Synthetic mode uses original-project fallback art.

Ranks apply explicit additive or starting-value percentage totals; temporary ranks are separate from the permanent shop. Extra attacks produce repeated melee strikes or additional arrows/bolts; extra targets expand cleave, grant arrow piercing or raise the spell splash target limit. Area affects melee reach/width or spell splash radius and is not offered to ordinary bows. Piercing tracks already-hit enemy IDs; splash/strikes respect terrain. Status effects tick over time; healing, criticals, retaliation and companion upgrades have real gameplay behavior. Projectiles are capped at 192. Fully exhausted pools offer Recovery instead of capped upgrades. Rank/base-stat snapshots carry into and back from a cow portal within a run; new runs reset them.

Validation covers five-tier caps, class filtering, distinct area/target/attack effects, real multihit/piercing/DOT, mixed unique choices, exhausted pools, menu selection/Play/shop access, correct next-area unlock, once-only gold and repeat counts across save/reload/history trimming. Menu/cards/area switching/records were rendered and visually checked with an isolated save.

Final validation: 63 Python tests and all Godot gameplay, tier, menu, audio and persistence checks passed. Imported Cathedral/Tristram and cow-event smoke checks passed. Main menu, icon cards, area switching and achievement records were visually checked on the native renderer. The runtime default scene is now the survival main menu; original movement demo launchers select their legacy scene explicitly. Balance across the expanded upgrade pool remains playtesting.
