# Historical development notes

These notes describe earlier development stages and can contain superseded behavior. See the root README.md for the current app.

# GameShift

A local desktop manager and original 2D survival runtime. Python 3.12+ / PyQt6, SQLite, Pillow, JSON Schema and Godot **4.6.2**. Current build provides the M0 foundation and a standalone administrator game inspector; the complete survival loop and playable Diablo campaign are not implemented yet.

## Run on Windows

Dependencies are installed on this development machine. Double-click:

- `Run_Inspector.bat` — archive inspection, profile metadata, previews and local working imports.
- `Run_Manager.bat` — library, installation identity and Play demo.
- `Run_Demo.bat` — the original movement demo directly.

For a fresh source installation, run `python -m pip install -r requirements-dev.txt`, then `python scripts/setup_stormlib.py`. No Windows virtual environment is created. Set `GODOT_BIN` to your Godot 4.6.2 executable or choose it in manager Settings. This machine's existing executable is recorded in ignored `.local/tooling.json`; that machine-specific path is not shipped.

## Inspector workflow

1. Launch Inspector and choose your installed game folder (`G:\Games\Diablo` for the current research baseline).
2. Selecting or entering a valid folder automatically inventories archives, identifies edition evidence, builds a searchable SQLite asset database, imports known named resources, and saves a draft profile/catalog. No separate inspection/import/save click is needed. Source installations stay unchanged; **Refresh asset database** explicitly reruns preparation.
3. Choose an archive. Named resources are matched from bundled catalogs and internal `(listfile)` entries where available. Disable **Named resources only** to see unnamed blocks; filenames are not guessed.
4. Add a candidate path list (one path per line) or probe an exact path when doing administrator research. Filter by asset type and inspect format/dimensions/frame count/audio duration. Preview cached images, palette swatches, supported sprite frames or terrain tile-ID grids; scrub/animate sprite frames or play cached audio. Width 0 uses automatic geometry; an explicit width supports manual preview research.
5. In **Edition profile**, edit edition/game IDs, distribution, language and executable version. Check the archives to include and save a schema-validated profile/catalog pair outside the game directory. Drafts remain inspected, not fully verified.
6. Select named asset rows (Ctrl/Shift or Ctrl+A) and use **Local imports → Import selected named resources**. The app stages the extraction, records hashes/provenance, produces PAL swatch PNGs and verifies WAV headers. Raw CEL/CL2 files are preserved and supported layouts get cached frame previews; remaining width/palette/animation mappings and full terrain rendering are still pending. Repeat the same unchanged selection to reuse its cache.

Profiles saved by administrators are local drafts. Reviewed profiles belong in `profiles/`, catalogs in `catalogs/` for the next release. No imported payload belongs in either folder.

## Command-line entry points

```powershell
python -m inspector.app --folder "G:\Games\Diablo"
python -m inspector.app --folder "G:\Games\Diablo" --prepare
python -m manager.app --portable
python scripts/check.py
python scripts/package_release.py
```

Inspector defaults to `.local/inspector/`; override with `--workspace`. Each installation has its own `games/<installation-id>/` directory. Its atomically activated generation contains `assets.sqlite3`, `profile.json`, `catalog.json` and `preparation.json`; local payloads/previews are in its `imports/` folder. Unnamed blocks are indexed without fabricated names, and incomplete decoders/mappings remain explicit. The manager normally stores SQLite state in the platform user data folder; `--portable` uses `.local/`, and `GAMESHIFT_DATA_DIR` overrides it. Linux/macOS run files are under `scripts/`; Python/Godot portability checks are prepared but only Windows has been exercised here. For MPQ extraction on Linux/macOS install StormLib 9.40 and set `STORMLIB_PATH` to the native shared library.

## Organization

- `manager/`: desktop player-facing manager and local database.
- `inspector/`: administrator UI, metadata/profile services and tests.
- `adapters/base/`: adapter interface and shared read-only MPQ backend.
- `profiles/`, `catalogs/`, `schemas/`: redistributable metadata and contracts.
- `runtime/`, `demo_assets/`: Godot project and original placeholder resources.
- `docs/`, `scripts/`, `tests/`: documentation, build/run tools and synthetic tests.
- `.local/`: private working imports, indexes, draft profiles and previews; excluded from Git/packages.
- `.tools/`: local dependency tooling; excluded from Git/packages.

The current GOG English Diablo 1.0.9.2 archive identity is documented in `docs/diablo1-feasibility.md`. Earlier retail/CD editions and other languages are unverified. No Blizzard executable is run, no original story/saves are reconstructed, and no proprietary assets are shipped.

## Troubleshooting

Missing PyQt6/jsonschema/Pillow: install requirements with the same Python used by run files. Missing StormLib: run `scripts/setup_stormlib.py` on Windows. Wrong Godot version/path: update Settings or `GODOT_BIN`. Unknown archive: the current inspector only supports classic MPQ v0 headers at offset zero. The measured GOG Diablo/Hellfire filename catalogs are bundled; other editions may need administrator candidate paths because classic Diablo's main archive has no listfile. A known filename does not imply validated sprite decoding.

Build scripts produce a **source ZIP**, not a standalone executable installer. See `docs/STATUS.md` for checks, limits and next steps.

## Validated local resource preview

After automatic preparation of the known GOG Diablo installation, use **Local imports → Preview validated assets in Godot**. This loads locally normalized cathedral terrain and a fully decoded eight-direction skeleton walk sheet. WASD moves the actor; Escape exits. It is a resource-validation scene with authored preview timing, not a survival campaign.

Select `levels/l1data/l1.til` in the terrain filter to browse composed cathedral tiles with the slider. Representative skeleton state previews use `l1_1.pal` plus `white.trn`. Palette, translation and direction selectors let administrators compare other resources. The database includes animation mapping candidates and resource dependencies; original timing and gameplay collision/navigation remain unverified.

## Direct imported demo

Run `Run_Imported_Demo.bat` to open the latest validated local resources without navigating the inspector. WASD moves the skeleton and automatically switches idle/walk; hold 3 for attack, 4 for hit, 5 for death; Escape exits. The launcher uses a complete flat floor tile and existing cached sheets. It is an asset/movement demo; combat, enemies, XP and upgrades are the next gameplay milestone. Headless demo and all 60 tests passed.


## Five-minute survival demo

Run `Run_Survival_Demo.bat` after Inspector preparation to play Cathedral Survival using cached local Diablo GOG assets. The Warrior moves with WASD or arrow keys and attacks nearby skeletons automatically. Collect blue XP drops; choose one of three upgrades with 1–3 or click. Space/Escape pauses, R restarts after death or victory. Survive five minutes against increasingly frequent spawns and elite enemies. Six upgrades include damage, attack speed, health, movement, pickup range and up to two allied wisps. Wisps are original geometric effects.

`Run_Synthetic_Survival.bat` runs the same gameplay with original artwork and requires no game installation. Gameplay settings and upgrade definitions live in the survival manifest. Local Diablo manifest: `.local/demo/survival.json`; decoded Warrior sheets: `.local/demo/warrior/`; results: `.local/demo/progress/diablo1.json` (last 50 runs and best scores). Preparation reuses source hashes and cached normalized sheets. Nothing is written to the installed game folder.

This is an authored gameplay prototype with illustrative animation timing, a flat cathedral floor, melee combat and a limited actor set. Full campaign support, terrain collision, additional games, audio integration and final balancing remain future work. Automated checks cover seeded spawning, combat/death/XP, upgrade pause, summons, enemy limits, a five-minute simulation and native scene startup.


### Class progression

The survival demo opens on class selection. Warrior is available immediately (100 HP, automatic sword cleave). Rogue unlocks after 500 cumulative kills across completed runs (75 HP, faster movement, automatic arrows). Sorcerer unlocks after a five-minute victory (65 HP, firebolts with splash damage). Locked buttons show their requirements and lifetime progress. Existing saved run history contributes automatically; lifetime totals and unlocks persist beyond the last-50-run history limit. Finished runs record the selected class. Choose class on the results screen; R retries the current class. Abandoned runs do not count.

Diablo class animations are prepared from cached Warrior, Rogue and Sorcerer CL2 files into `.local/demo/classes/` using source-hash cache keys. Projectile graphics are original code-drawn effects; timing and stats are authored for this prototype. Synthetic mode uses the same original avatar for each class while preserving different gameplay.


### Gold and permanent shop

Completed runs award one gold per kill, one per ten seconds survived, plus 50 for victory. The results screen displays earnings; class selection opens the permanent shop. Vitality gives +10 starting HP per rank (50 base price), Power +5% starting damage (75), Haste +3% movement speed (60). Each has ten ranks and its next price equals base price times next rank. Bonuses apply to all classes on the next run; in-run upgrades remain temporary. Gold, purchases, lifetime kills and unlocks share the per-profile progress JSON. Existing retained run history receives gold once during migration; repeat loads do not award it again. Abandoned runs award nothing. Failed save operations keep your gold and do not activate a purchase.


The permanent shop uses Movement, Defense, General and Class tabs. Movement improves run speed; Defense offers maximum HP and contact-damage reduction (minimum one damage per hit); General improves damage and XP collection. Class bonuses add Warrior cleave targets, Rogue bow damage, or Sorcerer firebolt splash radius. Locked classes cannot buy their bonuses. Bonuses use the same gold/save rules and only affect the next run; shared in-run upgrade choices remain separate.


## Original Tristram survival arena and character sheet

Launch `Run_Tristram_Survival.bat` to reconstruct the original base Diablo town from cached `DIABDAT.MPQ` terrain and four sector DUN files. Sector placement follows the format reference: sector1 (46,46), sector2 (46,0), sector3 (0,46), sector4 (0,0). DUN tile IDs are one-based; TIL piece references are zero-based. The normalized 96×96 map preserves buildings, trees, rocks, paths and river. Town quest/warp-state modifications, NPCs and Hellfire town changes are omitted.

The adapter decodes all 3547 referenced primitives, 1258 MIN pieces and 342 TIL tiles. SOL flags supply movement/missile collision; the largest connected region has 3817 walkable cells. Player movement slides at obstacles, enemies use a shared breadth-first distance field with persistent waypoints, ranged shots stop at solid scenery, and spawn locations use connected walkable cells outside the viewport. Raised scenery sorts with actors so the player can walk behind it. This is a survival adaptation of the static town geometry, not original Diablo gameplay or an exact quest-state reconstruction.

Source-hash caches live under `.local/demo/maps/tristram/` (piece atlas, map.json, town-overview.png). `.local/demo/tristram-survival.json` is the runtime manifest; Tristram shares class/gold/shop progression with the cathedral arena. `Run_Survival_Demo.bat` still launches the cathedral. Original pixels/maps remain local and excluded from source distributions.

Press C during play to view the character sheet and close it again. Original `data/char.cel` (320×352) and `ctrlpan/spelicon.cel` (56-pixel frames) are normalized into `.local/demo/ui/` using the town palette. The character panel is used in the sheet; the spell icon atlas is prepared for later icon mappings. The sheet shows current class, level, XP, health, gold, actual combat/movement values, permanent bonuses and selected run upgrades. Original attributes, mana and resistances that the prototype does not implement are shown as dashes. Gameplay and attack timers pause while the sheet is open. Synthetic mode uses the same data sheet without proprietary artwork.

Format references: https://github.com/diasurgical/devilutionX/blob/master/Source/levels/town.cpp and https://github.com/diasurgical/devilution/blob/master/Source/control.cpp (format research only; no third-party game engine code distributed).


## Treasure goblin and eight-minute cow hunt

An original treasure goblin sprite sheet was created with the built-in image_gen tool and is stored at `runtime/resources/treasure_goblin.png`; its complete generation prompt and 4×4 directional layout are recorded in the adjacent `.provenance.json`. The generated transparent image is used unchanged, with four run frames for south/west/east/north directions. This artwork is original and can ship with the source; locally decoded cow art remains private.

Normal survival runs check for a rare goblin every 30 active seconds with an 8% chance, limited to one active goblin. It has 60 HP, flees at speed 135 with brief rests, causes no contact damage, and escapes after 45 seconds. Killing it drops normal XP plus a treasure pickup containing 30 XP, 15 healing and 25 gold. Collect the treasure to add its gold to the normal end-of-run reward. A 1% roll on goblin death opens a cow portal for 60 active seconds. Approach within 85 pixels and press E to enter. Probabilities are authored configuration values; normal launches retain rarity. Each interactive run uses a fresh seed recorded in its summary; smoke tests retain a deterministic seed.

The portal starts an authored pasture survival arena using the locally cached original `towners/animals/cow.cel` animation and town palette, or an original geometric cow in synthetic mode. The base survival run pauses while the hunt is active. The countdown begins at 08:00 and counts active gameplay time down to zero; pause, upgrades and the character sheet pause it as usual. Cows continue spawning after 500 kills, subject to a 220-live-enemy cap. Reaching 500 does not trigger an early completion message or end the hunt. At timer zero, 500 or more cow kills earns exactly TWO gold coins; 499 or fewer earns zero. Cow kills/time do not produce the ordinary survival gold payout. Early defeat earns no cow challenge reward. The event result is saved once. Return to survival restores the suspended base timer and carries current health, XP and run upgrades; defeat also ends the base run. Cow kills count toward cumulative class progression; only a normal survival victory unlocks Sorcerer.

`Run_Treasure_Event_Demo.bat` is an explicit playtest launch: one visible goblin and a guaranteed portal on its death. `Run_Cow_Level_Demo.bat` opens the eight-minute hunt directly. Normal cathedral/Tristram launch files retain the rare spawn and 1% portal chance. The hunt is our own event, not an original Diablo 1 cow level.

Checks cover goblin fleeing, spawn limits, collected loot, forced portal rolls, portal consumption, suspended base timer, full 480-second simulation, continued spawning after 500, exact success/failure payout, save-once behavior and return to the original run.

Cow-hunt countdown: a large top-right timer shows minutes and seconds. At 01:00 remaining it turns red, gains a dark red outline and gently pulses in size/color. It remains legible and does not flash off. Paused gameplay freezes the countdown; urgency is a visual cue and does not alter rewards or spawn rules.


## Current area completion and class selection

All normal survival areas now start at 08:00 (480 active seconds), matching the cow hunt. At zero, gameplay stops and the area rewards screen shows area/class, duration, kills by enemy type, collected XP, XP/healing/treasure pickup counts, healing restored, loot gold, total gold earned and wallet balance. These details are recorded with the completed run. Normal rewards still use kills, survival time, victory bonus and collected loot gold; cow hunts retain exactly two gold for 500+ kills at expiry. Early death also shows the collected results. A portal still suspends the previous area and its remaining time until returning. Existing class unlocks remain valid; new Sorcerer unlock text refers to an eight-minute normal-area victory.

Class selection displays a cached first-frame sprite of each class to the left of its text, including disabled/locked classes. Locally imported Warrior/Rogue/Sorcerer art is used when available; synthetic mode uses original project art.


## Sequential map challenges

Each area has a configured sequence of enemy-specific kill milestones. Cathedral/synthetic: 100, 250, 400 skeletons; Tristram: 75, 175, 300 skeletons; cow hunt: 100, 250, 750 cows. Only the current challenge appears in a compact gameplay line. Reaching its cumulative area kill target unlocks the next; completed and locked challenges do not form a gameplay list. Each completed milestone awards one additional gold only when the eight-minute area timer expires; early death awards no challenge bonus. Rewards show the full sequence, counts and awarded gold; run history stores these details. Progress resets for each new area/run; suspended portal areas retain their own progress. Cow hunt challenge gold is additional to the existing two-gold 500-kill bonus.


## Combat audio associations

The Diablo adapter ships metadata-only sound rules in `adapters/diablo1/audio.py`. Preparation writes `.local/demo/audio/audio-mappings.json` containing event names, internal source paths, local WAV paths, source hashes and association confidence. No extracted audio is distributed. Sword swings use Swing/Swing2, Rogue bow fire BFire, Sorcerer firebolt casting Cast2 (verified Firebolt spell-table assignment). Skeleton SkelAxe sound suffixes a/h/d identify attack/hit/death, with two variants each. Hero pain/death uses the respective Warrior/Rogue/Sorcerer 69/71 files. Cow combat associations reuse town cow calls and are explicitly authored, as are firebolt impact choices. Gold collection and rare portal opening also have effects.

Runtime WAV streams are loaded once and shared in an eight-voice pool; two voices are reserved for player effects. Nearby enemy events use distance falloff, stereo panning, quiet volume and per-key throttling; events beyond 650 pixels are dropped. Variants have subtle pitch variation. Combat audio follows authored runtime strike/damage/death events rather than attempting exact original animation-frame timing. Cow calls are associated with our survival combat, not original cow attack animations. The generated treasure goblin has no invented original-game voice; loot and portal sounds supply feedback. M toggles mute; pause, upgrades and character inspection pause effects. Area transitions/restarts stop old voices. Synthetic mode remains silent unless it is given an original sound bank.

Verification covers stream reuse, bounded crowd voices, player voice reservation, range culling, repeat throttling, mute and installed-game WAV loading. Primary format references are recorded in the local mapping document.


## Implemented main menu, area chain and lifetime challenge records

Use `Run_GameShift.bat` to open the main menu. Select a character and an unlocked area, then press Play. The menu includes the permanent shop and Achievements & records (achievement badges plus repeat-completion counts per area/challenge). Cathedral is available initially; clearing Cathedral unlocks Tristram. A completed area remains replayable. Repeated clears increment clear counts but do not skip or unlock later areas. Only the two current normal areas are in this chain; the cow hunt remains a special portal event. Explicit treasure/cow playtest launchers bypass ordinary arena access for testing.

Challenge gold is now awarded only for the first timed completion of each challenge in each area. Claimed milestones are skipped by the active HUD on replay, so the next unfinished milestone becomes available. Counts still track every successful repeat for bragging rights, including the special 500-cow challenge. The 500-cow two-gold reward is also once-only. Normal non-challenge run rewards can still be earned on replays. Save migration retains earlier balances/unlocks and infers already-paid challenges from stored run summaries; completion ledgers and counters persist beyond the 50-run history limit. Completion in one area does not claim a challenge with the same ID in another area. Gold and result details are saved exactly once per finished run.

## Implemented tiered in-run upgrades

The authored catalog is `runtime/resources/upgrades.json`: 26 upgrades, typically five ranks, with Spirit Ally capped at two. It includes extra attacks per cycle, +10% area per tier, extra targets, damage, attack interval, health, movement, pickup/weapon range, armor, regeneration, critical chance/power, knockback, healing on kill, healing-drop chance, XP bonuses, wisps and their damage/speed, Warrior bleeding/retaliation, Rogue poison/projectile speed and Sorcerer burning/splash strength. Prerequisites and class eligibility filter choices; capped upgrades leave the pool. Cards mix owned/new choices when possible, show the next tier, exact before/after values and themed icons from the locally decoded spell-icon atlas. Synthetic mode uses original-project fallback art.

Ranks apply explicit additive or starting-value percentage totals; temporary ranks are separate from the permanent shop. Extra attacks produce repeated melee strikes or additional arrows/bolts; extra targets expand cleave, grant arrow piercing or raise the spell splash target limit. Area affects melee reach/width or spell splash radius and is not offered to ordinary bows. Piercing tracks already-hit enemy IDs; splash/strikes respect terrain. Status effects tick over time; healing, criticals, retaliation and companion upgrades have real gameplay behavior. Projectiles are capped at 192. Fully exhausted pools offer Recovery instead of capped upgrades. Rank/base-stat snapshots carry into and back from a cow portal within a run; new runs reset them.

Validation covers five-tier caps, class filtering, distinct area/target/attack effects, real multihit/piercing/DOT, mixed unique choices, exhausted pools, menu selection/Play/shop access, correct next-area unlock, once-only gold and repeat counts across save/reload/history trimming. Menu/cards/area switching/records were rendered and visually checked with an isolated save.


## Base Diablo zones and enemy rosters — 2026-10-12

Base Diablo contains 16 normal dungeon floors (four each for Cathedral, Catacombs, Caves and Hell), one town, and four playable separate quest levels: Skeleton King's Lair, Bone Chamber, Poisoned Water Supply and Archbishop Lazarus' Lair. The archive also contains the unused Maze set-map, included here as a bonus survival zone. GameShift now has 22 corresponding eight-minute survival zones. Hellfire's extra areas and the authored cow event are outside this base-game count.

The metadata-only zone catalog is runtime/resources/zones.json. Legacy cathedral and tristram IDs retain their saved progress and their original Cathedral → Tristram unlock order. The chain continues through the remaining dungeon floors, with quest areas interleaved near their original locations. Each timed victory unlocks only its immediate successor; later titles remain concealed in the scrolling main menu. Old challenge claims and balances remain intact.

Regular dungeon floors use distinct deterministic survival layouts with their original regional CEL/MIN/TIL/SOL tilesets. They do not reproduce Diablo's procedural dungeon generator. Quest areas read the original DUN base tile layer and region palette; interactive doors, quest objects and scripted state transitions are omitted. Zero DUN cells use the original region floor convention. All maps have cached baked floors, collision and missile grids, shared piece atlases and connected spawn regions. Only three area texture bundles remain cached at once; atlas textures are shared.

catalogs/diablo1/monster_metadata.json records base-game monster identities, original sprite widths, graphic/sound paths, TRN recolors, availability flags, floor ranges and DUN monster-ID conversion. Range conversion follows the original floor formula (table level // 2 + 1); unavailable ordinary types are excluded. Floor 16 uses the explicit Blood Knight/Advocate roster. Quest rosters come from their stored DUN monster layers. Tristram has no original hostile monsters, so its survival invasion deliberately uses the floor-one roster.

The local importer prepares 95 enemy variants with idle, walk, attack, hit and death animations and per-type attack/hurt/death audio. Only the selected area's enemy sprite sheets remain resident. Butcher (floor 2), Skeleton King, Archbishop Lazarus and Diablo are once-per-run late encounters, with Red Vex and Black Jade in Lazarus's roster. Survival health, movement and attack tuning are authored; archers and casters have aimed projectiles that respect walls and invulnerability. Full original AI, spell systems and quest scripts are not reproduced.

Each zone has sequential 15/40-kill milestones for the enemy types it actually spawns, plus a boss-defeat milestone where relevant. Existing Cathedral/Tristram skeleton milestones remain as legacy milestones. The HUD shows only the active milestone; each challenge pays one gold only on its first successful timed completion in that area. Repeats keep their bragging-rights counts.

Source references: https://github.com/diasurgical/devilution/blob/master/Source/monstdat.cpp ; https://github.com/diasurgical/devilution/blob/master/Source/monster.cpp ; https://github.com/diasurgical/devilution/blob/master/Source/setmaps.cpp ; https://github.com/diasurgical/devilution/blob/master/Source/diablo.cpp . Original decoded assets and maps remain in ignored .local/demo/maps/zones and .local/demo/monsters, never in the source release.


### Scenery, impact effects and timed pickups — 2026-10-12

Generated survival scenery uses verified regional props instead of decorative stairs. Types alternate, placement is jittered, and walkable floor variants break repetition. A complete base floor is baked underneath solid scenery so omitted ground pixels do not resemble black holes. Cathedral alternates the two pillar structures CAT-070 and CAT-071; corner-wall props were removed. Cached maps use survival-zones-6.

Original MPQ blood1/blood3, bone1/bone2 and metlhit1 effects provide hit spray, six-second flesh splatters, skeletal fragments and armored hit feedback. Sprites are cached, depth-sorted and capped at 96 effects. Repeated DOT ticks do not add sprays; fatal hits emit only death effects.

Each area has three glowing walk-over collectibles: healing restores 35% maximum HP immediately, Speed grants +35% movement, and XP Magnet pulls nearby loot. Timed boosts start at 35 seconds. Lasting power has five run-upgrade tiers, adding 20% starting duration each (42/49/56/63/70 seconds), and extends active boosts by seven seconds per tier. Purple bars show names and time remaining and disappear at expiry. Timers pause with gameplay and carry across cow portal transitions.

Collected objects respawn after 45 active seconds at a reachable location at least 250 world units from the previous position. A player-centered minimap reveals collectibles within 450 units. New runs reset pickups and temporary boosts. The earlier player movement lock during attacks was removed at the user's request; moving and attacking now work together.


### Boost aura and collection audio — 2026-10-13

Active Speed or XP Magnet boosts display a subtle foot-level mist using the locally decoded 13-frame objects/vapor1.cel animation. A grayscale preview palette enables a pale violet tint. Five bounded sprite puffs drift around the feet, depth-sorted behind and in front of the player; animation follows active run time. The aura fades at timer expiry and is hidden after the run ends. This is an authored sprite-sheet animation driven by Godot, not a reproduction of the unidentified effect in the reference screenshot.

Power-up acquisition uses original sfx/items/magic1.wav, XP-dot collection uses sfx/items/invgrab.wav, and healing-drop collection uses sfx/misc/healing.wav. These associations are authored for GameShift. XP pickups have one reserved, quiet audio voice and a 160ms throttle; crowded collections coalesce without overwhelming attacks. The total voice pool remains eight. Gold retains its existing sound.
